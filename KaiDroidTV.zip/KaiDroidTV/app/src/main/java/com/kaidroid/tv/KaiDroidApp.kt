package com.kaidroid.tv

import android.app.Application

class KaiDroidApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Start the phone-controller server (HTTP + WebSocket) and advertise it on the LAN.
        ControllerHub.start(this)
    }
}
