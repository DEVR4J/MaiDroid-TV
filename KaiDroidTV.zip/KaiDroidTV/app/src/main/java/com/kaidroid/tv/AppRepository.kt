package com.kaidroid.tv

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File

data class KaiApp(
    val id: String,
    val name: String,
    val dir: File,
    val launchPath: String,
    val icon: File?,
    val designW: Int,
    val designH: Int
)

object AppRepository {
    private const val TAG = "AppRepository"

    fun appsDir(c: Context): File = File(c.filesDir, "apps").apply { mkdirs() }

    /** Copies apps bundled in assets/apps into internal storage the first time they are missing. */
    fun seedBundled(c: Context) {
        val names = c.assets.list("apps") ?: return
        for (n in names) {
            val target = File(appsDir(c), n)
            if (!target.exists()) copyAsset(c, "apps/$n", target)
        }
    }

    private fun copyAsset(c: Context, path: String, dest: File) {
        val kids = c.assets.list(path)
        if (kids.isNullOrEmpty()) {
            dest.parentFile?.mkdirs()
            c.assets.open(path).use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        } else {
            dest.mkdirs()
            kids.forEach { copyAsset(c, "$path/$it", File(dest, it)) }
        }
    }

    fun load(c: Context): List<KaiApp> {
        seedBundled(c)
        val result = mutableListOf<KaiApp>()
        val dirs = appsDir(c).listFiles { f -> f.isDirectory }?.sortedBy { it.name } ?: return result
        for (dir in dirs) {
            val mf = File(dir, "manifest.webapp")
            if (!mf.exists()) continue
            try {
                val json = JSONObject(mf.readText())
                val name = json.optString("name", dir.name)
                val launch = json.optString("launch_path", "/index.html").ifEmpty { "/index.html" }
                var icon: File? = null
                json.optJSONObject("icons")?.let { icons ->
                    val best = icons.keys().asSequence().mapNotNull { it.toIntOrNull() }.maxOrNull()
                    if (best != null) {
                        val f = File(dir, icons.optString(best.toString()).trimStart('/'))
                        if (f.exists()) icon = f
                    }
                }
                val kd = json.optJSONObject("kaidroid")
                result += KaiApp(
                    id = dir.name,
                    name = name,
                    dir = dir,
                    launchPath = launch,
                    icon = icon,
                    designW = kd?.optInt("design_width", 0) ?: 0,
                    designH = kd?.optInt("design_height", 0) ?: 0
                )
            } catch (e: Exception) {
                Log.w(TAG, "Bad manifest in ${dir.name}", e)
            }
        }
        return result
    }
}
