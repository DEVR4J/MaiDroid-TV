package com.kaidroid.tv

import android.content.Context
import android.util.Log
import java.io.File
import java.util.zip.ZipFile

/**
 * Imports app packages (.zip containing manifest.webapp + index.html) that the user drops into
 * Android/data/com.kaidroid.tv/files/import/ (copy via USB, adb push, or a TV file manager).
 */
object Installer {
    private const val TAG = "Installer"

    fun importDir(c: Context): File =
        (c.getExternalFilesDir("import") ?: File(c.filesDir, "import")).apply { mkdirs() }

    fun importPending(c: Context): List<String> {
        val installed = mutableListOf<String>()
        val zips = importDir(c).listFiles { f -> f.isFile && f.extension.equals("zip", true) } ?: return installed
        for (z in zips) {
            try {
                install(c, z)
                z.renameTo(File(z.parentFile, z.name + ".done"))
                installed += z.nameWithoutExtension
            } catch (e: Exception) {
                Log.e(TAG, "Failed to import ${z.name}", e)
                z.renameTo(File(z.parentFile, z.name + ".failed"))
            }
        }
        return installed
    }

    private fun install(c: Context, zip: File) {
        val safeName = zip.nameWithoutExtension.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        val target = File(AppRepository.appsDir(c), safeName)
        target.deleteRecursively()
        target.mkdirs()
        val targetPath = target.canonicalPath + File.separator

        ZipFile(zip).use { zf ->
            val entries = zf.entries().toList().filter { !it.name.startsWith("__MACOSX") }
            val names = entries.map { it.name }
            // If everything sits inside one top-level folder, strip it.
            val first = names.firstOrNull()?.substringBefore('/', "") ?: ""
            val prefix = if (first.isNotEmpty() && names.all { it.startsWith("$first/") }) "$first/" else ""

            for (e in entries) {
                val rel = e.name.removePrefix(prefix)
                if (rel.isEmpty()) continue
                val out = File(target, rel)
                if (!out.canonicalPath.startsWith(targetPath)) continue // zip-slip protection
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    zf.getInputStream(e).use { input -> out.outputStream().use { input.copyTo(it) } }
                }
            }
        }
        if (!File(target, "manifest.webapp").exists()) {
            target.deleteRecursively()
            throw IllegalStateException("No manifest.webapp in ${zip.name}")
        }
    }
}
