package com.kaidroid.tv

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONObject
import java.io.File
import kotlin.math.min

/**
 * Runs one HTML5 / KaiOS-style app full screen.
 *  - injects assets/kaios-shim.js (KaiOS API compatibility layer) before the app's own scripts
 *  - maps TV remote keys to KaiOS keys (SoftLeft / SoftRight / Enter / Backspace / digits)
 *  - forwards phone-controller input into the page
 *  - optional letterbox scaling for apps designed for small screens (manifest "kaidroid" block)
 */
class AppRunnerActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var shimJs: String
    private var backDownAt = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getStringExtra("id")
        val app = AppRepository.load(this).firstOrNull { it.id == id }
        if (app == null) {
            finish()
            return
        }
        shimJs = assets.open("kaios-shim.js").bufferedReader().use { it.readText() }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            @Suppress("DEPRECATION")
            settings.allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            settings.allowUniversalAccessFromFileURLs = true
            settings.mediaPlaybackRequiresUserGesture = false
            isFocusable = true
            isFocusableInTouchMode = true
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    view.evaluateJavascript(shimJs, null) // fallback; shim is guarded against double load
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                    Log.d("KaiApp", "${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                    return true
                }
            }
        }

        val dm = resources.displayMetrics
        if (app.designW > 0 && app.designH > 0) {
            val w = (app.designW * dm.density).toInt()
            val h = (app.designH * dm.density).toInt()
            root.addView(web, FrameLayout.LayoutParams(w, h, Gravity.CENTER))
            val scale = min(dm.widthPixels / w.toFloat(), dm.heightPixels / h.toFloat())
            web.scaleX = scale
            web.scaleY = scale
        } else {
            root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        setContentView(root)
        hideSystemUi()

        web.loadUrl(prepareEntry(app))
        web.requestFocus()
    }

    /** Writes a copy of the entry page with the shim inlined in <head>, so it runs before app scripts. */
    private fun prepareEntry(app: KaiApp): String {
        val rel = app.launchPath.trimStart('/')
        val path = rel.substringBefore('?').substringBefore('#')
        val suffix = rel.substring(path.length)
        val f = File(app.dir, path)
        if (!f.exists()) return "about:blank"
        if (f.extension.lowercase() !in listOf("html", "htm")) return "file://${f.absolutePath}$suffix"

        val tag = "<script>$shimJs</script>"
        var html = f.readText()
        val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
        val htmlTag = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(html)
        html = when {
            head != null -> html.replaceRange(head.range.last + 1, head.range.last + 1, tag)
            htmlTag != null -> html.replaceRange(htmlTag.range.last + 1, htmlTag.range.last + 1, tag)
            else -> tag + html
        }
        val out = File(f.parentFile, "__kd_" + f.name)
        out.writeText(html)
        return "file://${out.absolutePath}$suffix"
    }

    private fun js(code: String, cb: ((String?) -> Unit)? = null) {
        web.evaluateJavascript(code, if (cb == null) null else ValueCallback { cb(it) })
    }

    private fun q(s: String) = JSONObject.quote(s)

    private fun keyName(code: Int): String? = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> "ArrowUp"
        KeyEvent.KEYCODE_DPAD_DOWN -> "ArrowDown"
        KeyEvent.KEYCODE_DPAD_LEFT -> "ArrowLeft"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "ArrowRight"
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
        KeyEvent.KEYCODE_BUTTON_A -> "Enter"
        KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BUTTON_L1 -> "SoftLeft"
        KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_BUTTON_R1 -> "SoftRight"
        KeyEvent.KEYCODE_STAR -> "*"
        KeyEvent.KEYCODE_POUND -> "#"
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> (code - KeyEvent.KEYCODE_0).toString()
        else -> null
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val state = if (e.action == KeyEvent.ACTION_DOWN) "down" else "up"

        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                if (e.repeatCount == 0) {
                    backDownAt = e.eventTime
                    // KaiOS apps handle Back as Backspace. If the page doesn't preventDefault it, we exit.
                    js("window.__kd ? __kd.key('Backspace','down') : false") { r -> if (r != "true") finish() }
                } else if (e.eventTime - backDownAt > 1200) {
                    finish() // hold Back to force-quit
                }
            } else {
                js("window.__kd && __kd.key('Backspace','up')")
            }
            return true
        }

        val name = keyName(e.keyCode)
        if (name != null) {
            js("window.__kd && __kd.key(${q(name)},${q(state)})")
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun onController(player: Int, key: String, state: String) {
        if (key == "Exit") {
            if (state == "down") finish()
            return
        }
        js("window.__kd && __kd.ctl($player,${q(key)},${q(state)})")
    }

    override fun onResume() {
        super.onResume()
        ControllerHub.sink = { p, k, s -> onController(p, k, s) }
        web.onResume()
    }

    override fun onPause() {
        ControllerHub.sink = null
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }
}
