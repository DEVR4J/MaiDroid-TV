package com.kaidroid.tv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import android.util.Log
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import org.json.JSONObject
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Phone-controller backend.
 *  - Serves assets/controller.html at http://<tv-ip>:8765/
 *  - Accepts WebSocket connections at /ws, assigns each phone a player number (1..8)
 *  - Advertises itself over mDNS/NSD as "_kaidroid._tcp" so a companion app can find it automatically.
 */
object ControllerHub {
    private const val TAG = "ControllerHub"
    const val PORT = 8765

    /** (player, key, state) -> called on the main thread. state is "down" or "up". */
    @Volatile
    var sink: ((Int, String, String) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val clients = CopyOnWriteArrayList<Client>()
    private var server: Server? = null

    val playerCount: Int get() = clients.size

    fun start(ctx: Context) {
        if (server != null) return
        val app = ctx.applicationContext
        val html = app.assets.open("controller.html").bufferedReader().use { it.readText() }
        val s = Server(html)
        try {
            s.start(0, false)
            server = s
        } catch (e: IOException) {
            Log.e(TAG, "Could not start controller server", e)
            return
        }
        registerNsd(app)
    }

    fun controllerUrl(): String = "http://${localIp()}:$PORT"

    fun localIp(): String {
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return "?"
            for (nif in ifaces) {
                if (!nif.isUp || nif.isLoopback) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && addr.isSiteLocalAddress) return addr.hostAddress ?: "?"
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "localIp failed", e)
        }
        return "?"
    }

    private fun registerNsd(app: Context) {
        try {
            val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
            val info = NsdServiceInfo().apply {
                serviceName = "KaiDroid TV"
                serviceType = "_kaidroid._tcp."
                port = PORT
            }
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) { Log.w(TAG, "NSD register failed $code") }
                override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
                override fun onServiceRegistered(i: NsdServiceInfo) { Log.i(TAG, "NSD registered as ${i.serviceName}") }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
            })
        } catch (e: Exception) {
            Log.w(TAG, "NSD unavailable", e)
        }
    }

    private fun nextPlayerId(): Int {
        val used = clients.map { it.player }.toSet()
        for (i in 1..8) if (i !in used) return i
        return 8
    }

    private class Server(val html: String) : NanoWSD(PORT) {
        override fun openWebSocket(handshake: IHTTPSession): WebSocket = Client(handshake)

        override fun serve(session: IHTTPSession): Response {
            val upgrade = session.headers["upgrade"]
            return if (upgrade != null && upgrade.equals("websocket", ignoreCase = true)) {
                super.serve(session)
            } else {
                newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
            }
        }
    }

    private class Client(handshake: NanoHTTPD.IHTTPSession) : NanoWSD.WebSocket(handshake) {
        var player = 0

        override fun onOpen() {
            player = nextPlayerId()
            clients.add(this)
            try {
                send(JSONObject().put("type", "assigned").put("player", player).toString())
            } catch (e: IOException) {
                Log.w(TAG, "send failed", e)
            }
        }

        override fun onClose(code: NanoWSD.WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) {
            clients.remove(this)
        }

        override fun onMessage(message: NanoWSD.WebSocketFrame) {
            try {
                val json = JSONObject(message.textPayload)
                if (json.optString("type") == "key") {
                    val key = json.optString("key")
                    val state = json.optString("state", "down")
                    if (key.isNotEmpty()) {
                        val p = player
                        main.post { sink?.invoke(p, key, state) }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "bad message", e)
            }
        }

        override fun onPong(pong: NanoWSD.WebSocketFrame?) {}

        override fun onException(exception: IOException?) {
            clients.remove(this)
        }
    }
}
