package com.kaidroid.tv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** KaiOS-style home screen: status bar with clock, a D-pad navigable app grid, and a soft-key bar. */
class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var hint: TextView
    private lateinit var grid: GridView
    private var apps: List<KaiApp> = emptyList()

    private companion object {
        const val REQ_PICK_ZIP = 4201
    }

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("EEE d MMM   HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 15_000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0E1224.toInt())
        }

        // Status bar
        val bar = FrameLayout(this).apply { setPadding(dp(40), dp(24), dp(40), dp(8)) }
        val title = TextView(this).apply {
            text = "KaiDroid TV"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
        }
        clock = TextView(this).apply {
            setTextColor(0xFF9AA3C7.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        }
        bar.addView(title, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(clock, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // App grid
        grid = GridView(this).apply {
            numColumns = 5
            horizontalSpacing = dp(16)
            verticalSpacing = dp(16)
            setPadding(dp(40), dp(16), dp(40), dp(16))
            clipToPadding = false
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(4), 0xFF5EEAD4.toInt())
                setColor(0x335EEAD4)
            }
            isFocusable = true
            setOnItemClickListener { _, _, pos, _ ->
                if (pos == 0) pickZip() else launch(apps[pos - 1])
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Soft-key / info bar
        hint = TextView(this).apply {
            setTextColor(0xFF9AA3C7.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(40), dp(8), dp(40), dp(20))
        }
        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val imported = Installer.importPending(this)
        if (imported.isNotEmpty()) {
            Toast.makeText(this, "Installed: ${imported.joinToString()}", Toast.LENGTH_LONG).show()
        }
        apps = AppRepository.load(this)
        grid.adapter = Adapter()
        grid.requestFocus()
        hint.text = "OK: open     +: install app from .zip     Phone controller: ${ControllerHub.controllerUrl()}"
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    /** Opens the system file picker so the user can choose an app .zip to install. */
    private fun pickZip() {
        val mimes = arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        val open = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        }
        try {
            startActivityForResult(open, REQ_PICK_ZIP)
        } catch (e: ActivityNotFoundException) {
            val get = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            try {
                startActivityForResult(get, REQ_PICK_ZIP)
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "No file picker on this device. Copy the .zip to ${Installer.importDir(this).absolutePath}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_ZIP || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val result = try {
                "Installed: ${Installer.installFromUri(this, uri)}"
            } catch (e: Exception) {
                Log.e("MainActivity", "Install failed", e)
                "Install failed: ${e.message ?: "invalid zip (needs manifest.webapp)"}"
            }
            runOnUiThread {
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                apps = AppRepository.load(this)
                grid.adapter = Adapter()
            }
        }.start()
    }

    private fun launch(app: KaiApp) {
        startActivity(Intent(this, AppRunnerActivity::class.java).putExtra("id", app.id))
    }

    private fun addTile(): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
        }
        val size = dp(88)
        val plus = TextView(this).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(0xFF5EEAD4.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 48f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(3), 0xFF5EEAD4.toInt())
                setColor(0x1A5EEAD4)
            }
        }
        tile.addView(plus, LinearLayout.LayoutParams(size, size))
        val label = TextView(this).apply {
            text = "Install app"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setPadding(0, dp(8), 0, 0)
        }
        tile.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return tile
    }

    private inner class Adapter : BaseAdapter() {
        // Position 0 is the "+" install tile; apps follow.
        override fun getCount() = apps.size + 1
        override fun getItem(position: Int): Any = if (position == 0) "add" else apps[position - 1]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            if (position == 0) return addTile()
            val app = apps[position - 1]
            val tile = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
            }

            val size = dp(88)
            val bmp = app.icon?.let { BitmapFactory.decodeFile(it.absolutePath) }
            if (bmp != null) {
                val iv = ImageView(this@MainActivity).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.FIT_CENTER }
                tile.addView(iv, LinearLayout.LayoutParams(size, size))
            } else {
                val hue = (Math.abs(app.name.hashCode()) % 360).toFloat()
                val letter = TextView(this@MainActivity).apply {
                    text = app.name.take(1).uppercase()
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
                    typeface = Typeface.DEFAULT_BOLD
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.75f)))
                    }
                }
                tile.addView(letter, LinearLayout.LayoutParams(size, size))
            }

            val label = TextView(this@MainActivity).apply {
                text = app.name
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(8), 0, 0)
            }
            tile.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return tile
        }
    }
}
