package com.kaidroid.tv

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** KaiOS-style home screen: status bar with clock, a D-pad navigable app grid, and a soft-key bar. */
class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var hint: TextView
    private lateinit var grid: GridView
    private var apps: List<KaiApp> = emptyList()

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("EEE d MMM   HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 15_000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0E1224.toInt())
        }

        // Status bar
        val bar = FrameLayout(this).apply { setPadding(dp(40), dp(24), dp(40), dp(8)) }
        val title = TextView(this).apply {
            text = "KaiDroid TV"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
        }
        clock = TextView(this).apply {
            setTextColor(0xFF9AA3C7.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        }
        bar.addView(title, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(clock, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // App grid
        grid = GridView(this).apply {
            numColumns = 5
            horizontalSpacing = dp(16)
            verticalSpacing = dp(16)
            setPadding(dp(40), dp(16), dp(40), dp(16))
            clipToPadding = false
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(4), 0xFF5EEAD4.toInt())
                setColor(0x335EEAD4)
            }
            isFocusable = true
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Soft-key / info bar
        hint = TextView(this).apply {
            setTextColor(0xFF9AA3C7.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(40), dp(8), dp(40), dp(20))
        }
        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val imported = Installer.importPending(this)
        if (imported.isNotEmpty()) {
            Toast.makeText(this, "Installed: ${imported.joinToString()}", Toast.LENGTH_LONG).show()
        }
        apps = AppRepository.load(this)
        grid.adapter = Adapter()
        grid.requestFocus()
        hint.text = "OK: open     Phone controller: ${ControllerHub.controllerUrl()}     " +
            "Add apps: copy .zip files to ${Installer.importDir(this).absolutePath}"
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun launch(app: KaiApp) {
        startActivity(Intent(this, AppRunnerActivity::class.java).putExtra("id", app.id))
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val app = apps[position]
            val tile = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
            }

            val size = dp(88)
            val bmp = app.icon?.let { BitmapFactory.decodeFile(it.absolutePath) }
            if (bmp != null) {
                val iv = ImageView(this@MainActivity).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.FIT_CENTER }
                tile.addView(iv, LinearLayout.LayoutParams(size, size))
            } else {
                val hue = (Math.abs(app.name.hashCode()) % 360).toFloat()
                val letter = TextView(this@MainActivity).apply {
                    text = app.name.take(1).uppercase()
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
                    typeface = Typeface.DEFAULT_BOLD
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.75f)))
                    }
                }
                tile.addView(letter, LinearLayout.LayoutParams(size, size))
            }

            val label = TextView(this@MainActivity).apply {
                text = app.name
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(8), 0, 0)
            }
            tile.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return tile
        }
    }
}
