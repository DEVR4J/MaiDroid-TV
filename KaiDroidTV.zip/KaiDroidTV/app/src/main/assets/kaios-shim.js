/* KaiDroid TV - KaiOS API compatibility shim.
 * Injected before the app's own scripts. Partial coverage: enough for typical HTML5 games and utilities.
 */
(function () {
  if (window.__kd) return;

  var codes = {
    ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39,
    Enter: 13, Backspace: 8, Escape: 27, SoftLeft: 0, SoftRight: 0
  };

  function makeKey(type, key) {
    var ev = new KeyboardEvent(type, { key: key, code: key, bubbles: true, cancelable: true });
    var kc = codes[key];
    if (kc === undefined && key.length === 1) kc = key.toUpperCase().charCodeAt(0);
    if (kc === undefined) kc = 0;
    try {
      Object.defineProperty(ev, 'keyCode', { get: function () { return kc; } });
      Object.defineProperty(ev, 'which', { get: function () { return kc; } });
    } catch (e) {}
    return ev;
  }

  function sendKey(key, state) {
    var target = document.activeElement || document;
    var ev = makeKey(state === 'up' ? 'keyup' : 'keydown', key);
    target.dispatchEvent(ev);
    return ev.defaultPrevented;
  }

  window.__kd = {
    version: 1,
    // Called by the native side for TV-remote keys. Returns true if the page called preventDefault().
    key: sendKey,
    // Called for phone controllers. Player 1 also acts as the normal keyboard/remote.
    ctl: function (player, key, state) {
      try {
        window.dispatchEvent(new CustomEvent('kaidroid:controller', {
          detail: { player: player, key: key, state: state }
        }));
      } catch (e) {}
      if (player === 1) sendKey(key, state);
    }
  };

  // --- DOMRequest-style helper ---
  function request(result, error) {
    var r = { result: result, error: error || null, onsuccess: null, onerror: null };
    setTimeout(function () {
      if (error) { if (typeof r.onerror === 'function') r.onerror({ target: r }); }
      else { if (typeof r.onsuccess === 'function') r.onsuccess({ target: r }); }
    }, 0);
    return r;
  }

  function define(obj, name, value) {
    try { if (!(name in obj)) Object.defineProperty(obj, name, { value: value, configurable: true, writable: true }); }
    catch (e) { try { obj[name] = value; } catch (e2) {} }
  }

  var nav = window.navigator;

  // mozApps: minimal "self" so apps that check their own manifest do not crash.
  define(nav, 'mozApps', {
    getSelf: function () {
      return request({ manifest: { name: document.title || 'App' }, origin: location.origin, launch: function () {} });
    },
    mgmt: { getAll: function () { return request([]); } },
    install: function () { return request(null, 'unsupported'); }
  });

  // mozSettings: persisted in localStorage.
  define(nav, 'mozSettings', {
    createLock: function () {
      return {
        get: function (name) {
          var v = null;
          try { var s = localStorage.getItem('__kd_setting_' + name); v = s === null ? undefined : JSON.parse(s); } catch (e) {}
          var o = {}; o[name] = v;
          return request(o);
        },
        set: function (obj) {
          try { for (var k in obj) localStorage.setItem('__kd_setting_' + k, JSON.stringify(obj[k])); } catch (e) {}
          return request(null);
        }
      };
    },
    addObserver: function () {},
    removeObserver: function () {}
  });

  // Device storage: not available (returns errors, never throws).
  var storageStub = {
    get: function () { return request(null, 'NotSupported'); },
    addNamed: function () { return request(null, 'NotSupported'); },
    delete: function () { return request(null, 'NotSupported'); },
    enumerate: function () { return request(null, 'NotSupported'); },
    available: function () { return request('unavailable'); }
  };
  define(nav, 'getDeviceStorage', function () { return storageStub; });
  define(nav, 'getDeviceStorages', function () { return [storageStub]; });

  // Alarms, message handlers, volume.
  define(nav, 'mozAlarms', {
    add: function () { return request(1); },
    getAll: function () { return request([]); },
    remove: function () {}
  });
  define(nav, 'mozSetMessageHandler', function () {});
  define(nav, 'volumeManager', { requestUp: function () {}, requestDown: function () {}, requestShow: function () {} });

  // KaiAds: no ads on this runtime; report an error so apps continue without them.
  if (!window.getKaiAd) {
    window.getKaiAd = function (opts) {
      if (opts && typeof opts.onerror === 'function') setTimeout(function () { opts.onerror('no-ads'); }, 0);
    };
  }

  // Hide mouse cursor; TV apps use the D-pad.
  try {
    var st = document.createElement('style');
    st.textContent = 'html,body{cursor:none}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}
})();
