# KaiDroid TV

A KaiOS-inspired launcher and HTML5 app runtime for Android TV.

## Build

1. Open this folder in Android Studio (Koala or newer). Let it sync; it will download Gradle 8.7 and the dependencies.
2. Run on an Android TV emulator or a real TV (enable Developer options, ADB debugging, then `adb connect <tv-ip>`).
3. Or build an APK: `Build > Build APK(s)`, then `adb install app-debug.apk`.

The app appears in the TV's app row (Leanback launcher). It is a normal app, not a replacement system home screen.

## What is included

- `MainActivity`: KaiOS-style home grid, clock, D-pad focus, shows the phone-controller URL.
- `AppRunnerActivity`: full-screen WebView runtime. Remote keys are mapped to KaiOS keys:
  - D-pad = Arrow keys, OK = Enter, Back = Backspace (hold Back for 1.2 s to force quit)
  - Red / Menu / L1 = SoftLeft, Green / R1 = SoftRight, number keys = digits
- `ControllerHub`: serves a phone controller page at `http://<tv-ip>:8765/` and a WebSocket at `/ws`. Each phone gets a player number. Advertised over mDNS as `_kaidroid._tcp`.
  - Player 1 acts as an extra remote. All players also emit `kaidroid:controller` events: `{player, key, state}`.
- `assets/kaios-shim.js`: partial KaiOS API layer (`mozApps`, `mozSettings`, `mozAlarms`, stubbed device storage, KaiAds stub).
- `Installer`: imports app packages.
- `assets/apps/coin-chase`: sample two-player game.

## Adding apps

An app is a folder (or zip) with `manifest.webapp` and `index.html`:

```json
{ "name": "My Game", "launch_path": "/index.html",
  "icons": { "128": "/icon.png" },
  "kaidroid": { "design_width": 240, "design_height": 320 } }
```

`kaidroid.design_*` is optional. When set, the app is rendered at that size and scaled to fit the TV with black bars.

Tap the **+ Install app** tile on the home screen and pick a `.zip` with the system file picker. Alternatively, copy `.zip` files to `Android/data/com.kaidroid.tv/files/import/` and reopen the launcher.

## Next steps

- Launcher navigation from the phone, and a phone companion app using NSD discovery.
- Gamepad API bridge (`navigator.getGamepads`) for games that expect a controller.
- More KaiOS API coverage, based on the apps you want to run.
- A proper TV banner image (320x180 with the app name).

Note: `KaiOS` is a trademark of KaiOS Technologies. Check the name before publishing, and only ship games you have the right to distribute.
